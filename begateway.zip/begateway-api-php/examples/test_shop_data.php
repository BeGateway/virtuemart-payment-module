<?php
\BeGateway\Settings::$shopId = 361;
\BeGateway\Settings::$shopKey = 'b8647b68898b084b836474ed8d61ffe117c9a01168d867f24953b776ddcb134d';
\BeGateway\Settings::$checkoutBase = 'https://checkout.begateway.com';
\BeGateway\Settings::$gatewayBase  = 'https://demo-gateway.begateway.com';
\BeGateway\Settings::$apiBase      = 'https://api.begateway.com';
?>
