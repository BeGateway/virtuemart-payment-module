<?php
\eComCharge\Settings::setShopId(115);
\eComCharge\Settings::setShopKey('1cf24f84fa4f6a152e1b55942308988cd8217851b1c065ab2549d74879119c41');
?>
