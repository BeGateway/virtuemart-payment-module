<?php
namespace eComCharge;

class Payment extends Authorization {
}
?>
