<?php
namespace eComCharge;

class Void extends ChildTransaction {
}
?>
