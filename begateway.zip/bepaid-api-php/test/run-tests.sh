#!/bin/bash

`which php` -f ecomcharge.php
